//#include "gwthd.h"
//#include "user.h"

//#define NULL 0 

/*void *yolo (void *arg){
	printf(1,"I am 2");
	exit();
	return NULL;
}

int
main(void)
{
	gwthd_t x;
	gwthd_create(&x, &yolo, NULL);
	wait();
	exit();   
}
*/

#include "gwthd.h"
#include "user.h"
#define NULL 0

static volatile int count = 0;

void *fct(void *arg)
{
	printf(1, "%s is beginning\n", (char *)arg);
	int i;
//	printf(1, "thread id %d\n", gwthd_id());
	for (i = 0; i < 5000000; i++)
	{
		count = count + 1;
	}
	printf(1, "%s is done\n", (char *)arg);
	gwthd_exit();
	return NULL;
}
int main()
{
	printf(1, "main: begin to 1 MILLION !!! NOW: %d\n", count);
	// Create
	gwthd_t p1, p2;
	gwthd_create(&p1, fct, "A");
	gwthd_create(&p2, fct, "B");
	printf(1,"tid %d\n", p1);
//	printf(1, "main id %d\n", gwthd_id());
	// Join
	gwthd_join(p1);
	gwthd_join(p2);
	// Done?? ALL GUCCI
	printf(1, "main is done with counting %d\n", count);
	exit();
}
