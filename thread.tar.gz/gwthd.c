#include "gwthd.h"
#include "user.h"
#define NULL 0
#define PGSIZE (4096) 


//creates new thd that executes function ptr passed in
//passes data to it as an arg
//returns 0 
int
gwthd_create(gwthd_t *childid, gwthd_fn_t fn, void *data)
{
	void * ustack = malloc((uint)PGSIZE);

	//if stack is empty
	if( (uint) ustack <= 0 ) {
		return -1;
	}

	*childid = clone(fn, ustack, data);
//	printf(1,"lol %d", *childid);	
	if (* childid  == -1) {
		return -1;	
	}
	
	
	//success
	return 0;
}

void
gwthd_exit(void)
{
	exit();
	return;
}

//executed by parent
//passes gwthd_id of child want to wait to terminate execution
//parent either allows child that has exited to be reclaimed
// or parent blocks waiting for child to terminate
int
gwthd_join(gwthd_t child)
{	
//	printf(1,"marico %d\n", child);
	void * stack;
	if (join(&stack,child) < 0) {
		return -1;
	}

	//success	
	printf(1,"free\n");	
	free(stack);
	printf(1,"YASSSS\n");

	return 0;
}

//return current thread's gwthd_t identitfier
//callable from procs and threads 
//returns unique id
gwthd_t
gthd_id(void)
{
//	struct proc * curproc = myproc();
	return 0;
//	if (curproc->thread == 1) {
//		return (gwthd_t)(curproc->pid);
//	}
//	return -1;	
}
